'use strict';

angular.module('todoListApp')
.controller('mainCtrl', function($scope, dataService) {

//---Libros
  $scope.addTodo = function() {
  	dataService.addTodo(function(response) {
  		$scope.todos.unshift(response.data);	
	});
  };
    
  dataService.getTodos(function(response) { 
      $scope.todos = response.data;
    });
  
  $scope.deleteTodo = function(todo, $index) {
    dataService.deleteTodo(todo, function(response) {	   
	    $scope.todos.splice($index, 1);	    
    });
  };
  
 $scope.saveTodo = function(todo, $index) {
    dataService.saveTodo(todo, function(response) {
	    console.log(response.data)
    });
  };

//---Autores
  $scope.addAuthor = function() {
  	dataService.addAuthor(function(response) {
  		$scope.authors.unshift(response.data);
	});
  };

  dataService.getAuthors(function(response) {
      $scope.authors = response.data;
    });

  $scope.deleteAuthor = function(author, $index) {
    dataService.deleteAuthor(author, function(response) {
	    $scope.authors.splice($index, 1);
    });
  };

 $scope.saveAuthor = function(author, $index) {
    dataService.saveAuthor(author, function(response) {
	    console.log(response.data)
    });
  };

})