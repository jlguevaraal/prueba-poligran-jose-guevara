'use strict';

angular.module('todoListApp')
.service('dataService', function($http) {

//-- Libros
  var todosGrailsServerUri = 'http://localhost:8080/books';

  this.getTodos = function(callback){
  	$http.get(todosGrailsServerUri).then(callback)
  };

  this.addTodo = function(callback) {
      var todo = {name: "Este es un nuevo libro", author: {name: "Por definir"}, completed: false};

      $http.post(todosGrailsServerUri,todo).then(callback);
  }

  this.deleteTodo = function(todo, callback) {
      $http.delete(todosGrailsServerUri + '/' + todo.id).then(callback);
  };

  this.saveTodo = function(todo, callback) {
      $http.put(todosGrailsServerUri + '/' + todo.id,todo).then(callback);
  };

//-- Autores
  var authorsGrailsServerUri = 'http://localhost:8080/authors';

  this.getAuthors = function(callback){
  	$http.get(authorsGrailsServerUri).then(callback)
  };

  this.addAuthor = function(callback) {
      var todo = {name: "Este es un nuevo autor", completed: false};
      $http.post(authorsGrailsServerUri,todo).then(callback);
  }

  this.deleteAuthor = function(author, callback) {
      $http.delete(authorsGrailsServerUri + '/' + author.id).then(callback);
  };

  this.saveAuthor = function(author, callback) {
      $http.put(authorsGrailsServerUri + '/' + author.id,author).then(callback);
  };

});
