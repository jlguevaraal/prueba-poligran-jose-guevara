package demo

import grails.rest.Resource

@Resource(uri='/books')
class Book {
    String name
    boolean completed
    Author author

    Book() {
    }

    Book(String name, Author author) {
        this.name = name
        this.author = author
    }

    static constraints = {
    }
}
