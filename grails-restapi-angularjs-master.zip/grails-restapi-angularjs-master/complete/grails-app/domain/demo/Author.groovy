package demo

import grails.rest.Resource

@Resource(uri='/authors')
class Author {
    String name
    boolean completed

    static constraints = {

    }
}
