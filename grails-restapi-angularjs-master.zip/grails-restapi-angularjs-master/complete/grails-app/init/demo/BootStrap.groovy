package demo

class BootStrap {

    def init = { servletContext ->


        def b = new Book(name: 'Building Microservices')
        b.setAuthor(new Author(name: 'Sam Newman'))
        b.save()

        b = new Book(name: 'Don Quijote de la Mancha')
        b.setAuthor(new Author(name: 'Miguel de Cervantes'))
        b.save()

        b = new Book(name: 'Poder')
        b.setAuthor(new Author(name: 'Robert Greene'))
        b.save()

        def authors = [
                [name: 'Milan Kundera'],
                [name: 'Nicolas Maquiavelo'],
                [name: 'Andres Caicedo']
        ].each { new Author(name: it.name).save() }

    }
    def destroy = {
    }
}
