// Place your Spring DSL code here
beans = {
}
