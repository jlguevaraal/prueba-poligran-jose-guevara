CREATE TABLE tb_autor (
  id NUMBER
 ,nombre VARCHAR2(4000)
);

ALTER TABLE tb_autor
 ADD CONSTRAINT tb_autor_pk PRIMARY KEY (id);

CREATE UNIQUE INDEX tb_autor_ux_nombre
 ON tb_autor (nombre);
