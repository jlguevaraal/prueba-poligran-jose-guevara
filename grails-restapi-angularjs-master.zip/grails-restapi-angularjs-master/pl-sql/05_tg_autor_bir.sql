CREATE OR REPLACE TRIGGER tg_autor_bir
  BEFORE INSERT ON tb_autor
  FOR EACH ROW

BEGIN
  IF :new.id IS NULL THEN
    SELECT sq_autor.NEXTVAL
      INTO :new.id
      FROM dual;
  END IF;
END;
/
