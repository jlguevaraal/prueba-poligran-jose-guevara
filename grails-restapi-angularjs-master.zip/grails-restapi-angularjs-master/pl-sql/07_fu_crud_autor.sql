CREATE OR REPLACE FUNCTION fu_crud_autor ( 
  p_crud VARCHAR2
 ,p_nombre VARCHAR2
 ,p_id NUMBER DEFAULT NULL
 ) RETURN VARCHAR2 IS
  n_id NUMBER;
  n_count NUMBER;
  v_jason VARCHAR2(4000);
 BEGIN
  SELECT count(*)
    INTO n_count
    FROM tb_autor
   WHERE (nombre = p_nombre AND p_id IS NULL) OR
         (id = p_id AND p_id IS NOT NULL);
  -- Create
  IF p_crud = 'C' THEN
    IF n_count > 0 THEN
      RAISE_APPLICATION_ERROR(-20001,'Autor ya existe');
    END IF;
    SELECT sq_autor.NEXTVAL
      INTO n_id
      FROM dual;
    INSERT INTO tb_autor (id, nombre)
      VALUES (n_id, p_nombre);
    RETURN (n_id);
  END IF;
  -- Read
  IF p_crud = 'R' THEN
    IF n_count = 0 THEN
      RAISE_APPLICATION_ERROR(-20001,'Autor no existe');
    END IF;
    SELECT json_object('id' VALUE id
                      ,'nombre' VALUE nombre)
      INTO v_jason
      FROM tb_autor
     WHERE (nombre = p_nombre AND p_id IS NULL) OR
           (id = p_id AND p_id IS NOT NULL)
       AND ROWNUM = 1;
    RETURN (v_jason);
  END IF;
  -- Read All
  IF p_crud = 'RA' THEN
    SELECT json_object('id' VALUE id
                      ,'nombre' VALUE nombre)
      INTO v_jason
      FROM tb_autor;
    RETURN (v_jason);
  END IF;
  -- Update
  IF p_crud = 'U' THEN
    IF n_count = 0 THEN
      RAISE_APPLICATION_ERROR(-20001,'Autor no existe');
    END IF;
    UPDATE tb_autor
       SET nombre = p_nombre
     WHERE id = p_id;
    n_count := SQL%ROWCOUNT;
    IF n_count > 0 THEN
      RETURN (p_id);
    ELSE
      RETURN (n_count);
    END IF;
  END IF;
  -- Delete
  IF p_crud = 'D' THEN
    IF n_count = 0 THEN
      RAISE_APPLICATION_ERROR(-20001,'Autor no existe');
    END IF;
    DELETE
      FROM tb_autor
     WHERE id = p_id;
    n_count := SQL%ROWCOUNT;
    IF n_count > 0 THEN
      RETURN (p_id);
    ELSE
      RETURN (n_count);
    END IF;
  END IF;
 END;
 /
 