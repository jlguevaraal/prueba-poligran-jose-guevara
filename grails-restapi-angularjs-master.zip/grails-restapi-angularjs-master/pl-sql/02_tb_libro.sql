CREATE TABLE tb_libro (
  id NUMBER
 ,nombre VARCHAR2(4000)
 ,id_autor NUMBER
);

ALTER TABLE tb_libro
 ADD CONSTRAINT tb_libro_pk PRIMARY KEY (id);

ALTER TABLE tb_libro
 ADD CONSTRAINT tb_libro_fk1_id_autor
 FOREIGN KEY (id_autor)
 REFERENCES tb_autor (id);

CREATE UNIQUE INDEX tb_libro_ux_nombre_id_autor
 ON tb_libro (nombre, id_autor);

CREATE INDEX tb_libro_ix_id_autor
 ON tb_libro (id_autor);
