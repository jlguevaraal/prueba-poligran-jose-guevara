CREATE OR REPLACE TRIGGER tg_libro_bir
  BEFORE INSERT ON tb_libro
  FOR EACH ROW

BEGIN
  IF :new.id IS NULL THEN
    SELECT sq_libro.NEXTVAL
      INTO :new.id
      FROM dual;
  END IF;
END;
/
